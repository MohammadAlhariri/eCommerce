-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 28, 2020 at 08:33 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id9872892_mz_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `orderID` int(11) NOT NULL,
  `orderDate` date DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `orderTotal` float DEFAULT NULL,
  `orderState` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`orderID`, `orderDate`, `userID`, `orderTotal`, `orderState`) VALUES
(21, '2020-12-28', 3, 500, 'Not Shipped'),
(22, '2020-12-28', 4, 500, 'Not Shipped');

-- --------------------------------------------------------

--
-- Table structure for table `order_content`
--

CREATE TABLE `order_content` (
  `orderID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productID` int(11) NOT NULL,
  `productName` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `productDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `productPrice` float DEFAULT NULL,
  `productImage` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `productCategory` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `productState` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `productDate` date DEFAULT NULL,
  `sellerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `productName`, `productDescription`, `productPrice`, `productImage`, `productCategory`, `productState`, `productDate`, `sellerID`) VALUES
(3, 'bfbfbf', 'fbbfbf', 12222, 'https://mohammadalhariri.000webhostapp.com/MZ_eCommerce/uploads/5.jpg', 'laptops', 'Not Validate', '2020-12-27', 2),
(11, 'jghhfy', 'ygjhgg', 6555, 'https://mohammadalhariri.000webhostapp.com/MZ_eCommerce/uploads/2020&12&28&01&12&44.jpg', 'laptops', 'Not Validate', '2020-12-28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `sellerID` int(11) NOT NULL,
  `sellerName` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sellerPhone` int(11) DEFAULT NULL,
  `sellerEmail` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sellerAddress` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sellerPassword` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sellerImage` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`sellerID`, `sellerName`, `sellerPhone`, `sellerEmail`, `sellerAddress`, `sellerPassword`, `sellerImage`) VALUES
(1, 'mohammad', 123, 'ad@ad.com', '123', '123', NULL),
(2, 'Mohammad', 12345, 'ad1@ad.com', '123456', '123', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(11) NOT NULL,
  `userName` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userPhone` int(11) DEFAULT NULL,
  `userEmail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userAddress` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userPassword` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userImage` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userAnswer1` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `userAnswer2` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent` varchar(254) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `userName`, `userPhone`, `userEmail`, `userAddress`, `userPassword`, `userImage`, `userAnswer1`, `userAnswer2`, `parent`) VALUES
(2, 'Mohammad Alhariri', 76787062, '', '', '123', NULL, NULL, NULL, 'Users'),
(3, 'Mohammad Alhariri', 123, NULL, NULL, '123', NULL, NULL, NULL, 'Admins'),
(4, 'moh', 12345, NULL, NULL, '12345', NULL, NULL, NULL, 'Users');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `order_user_id_idx` (`userID`);

--
-- Indexes for table `order_content`
--
ALTER TABLE `order_content`
  ADD PRIMARY KEY (`orderID`,`productID`),
  ADD KEY `order_content_product_id_idx` (`productID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productID`),
  ADD KEY `product_seller_id_idx` (`sellerID`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`sellerID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `sellerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_user_id` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`);

--
-- Constraints for table `order_content`
--
ALTER TABLE `order_content`
  ADD CONSTRAINT `order_content_product_id` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`),
  ADD CONSTRAINT `oreder_content_order_id` FOREIGN KEY (`orderID`) REFERENCES `order` (`orderID`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_seller_id` FOREIGN KEY (`sellerID`) REFERENCES `seller` (`sellerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
