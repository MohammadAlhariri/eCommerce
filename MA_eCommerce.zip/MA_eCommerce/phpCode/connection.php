<?php


$con = mysqli_connect("localhost","id9872892_admin8846", "GfMbI=}wL]-%Mv+2","id9872892_mz_ecommerce");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

?> 