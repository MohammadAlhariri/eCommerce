package com.example.ma_ecommerce.prevalid;

import com.example.ma_ecommerce.model.Users;

public class Prevalid {
    public static Users online;
    public static final String userNumber = "userPhone";
    public static final String pass = "userPasspublic ";
    public static final String parentname="Users";
    public static final String id="1";


}
